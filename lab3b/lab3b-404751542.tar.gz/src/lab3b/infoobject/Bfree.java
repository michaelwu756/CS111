package lab3b.infoobject;

public class Bfree {
    private int blockNum;

    public Bfree(int blockNum) {
        this.blockNum = blockNum;
    }

    public int getBlockNum() {
        return blockNum;
    }
}
