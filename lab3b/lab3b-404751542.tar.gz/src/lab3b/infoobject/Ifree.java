package lab3b.infoobject;

public class Ifree {
    private int inodeNum;

    public Ifree(int inodeNum) {
        this.inodeNum = inodeNum;
    }

    public int getInodeNum() {
        return inodeNum;
    }
}